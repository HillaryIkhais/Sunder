'use client'

import { motion } from 'framer-motion'
import { useEffect, useRef } from 'react'

/* Animated data-stream particles in the background */
function DataStream() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
      {/* Vertical scan lines */}
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute top-0 bottom-0 w-px"
          style={{ left: `${12 + i * 11}%`, background: 'linear-gradient(to bottom, transparent, rgba(0,220,255,0.06), transparent)' }}
          animate={{ opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 3 + i * 0.4, repeat: Infinity, delay: i * 0.3 }}
        />
      ))}
      {/* Horizontal moving pulses */}
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.div
          key={`h${i}`}
          className="absolute h-px left-0 right-0"
          style={{ top: `${20 + i * 15}%`, background: 'linear-gradient(to right, transparent, rgba(0,220,255,0.12), transparent)' }}
          animate={{ x: ['-100%', '100%'] }}
          transition={{ duration: 6 + i, repeat: Infinity, delay: i * 1.2, ease: 'linear' }}
        />
      ))}
      {/* Central radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(0,220,255,0.05) 0%, transparent 70%)' }}
      />
    </div>
  )
}

/* Animated schema diff showing the silent mutation being caught */
function SchemaDiffCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.0, duration: 0.8 }}
      className="liquid-glass rounded-lg overflow-hidden w-full max-w-md"
    >
      {/* Terminal chrome */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
        <span className="status-dot" style={{ background: 'oklch(0.65 0.22 25)', boxShadow: '0 0 8px oklch(0.65 0.22 25)' }} />
        <span className="label-mono">DRIFT INTERCEPTED — vendor.stripe.api v4.2.1</span>
      </div>
      {/* Diff view */}
      <div className="px-4 py-4 font-mono-data text-xs space-y-1 leading-relaxed">
        <div className="flex items-center gap-3">
          <span className="w-3 text-red-400 font-bold select-none">−</span>
          <span className="text-red-400/70 line-through">&quot;price&quot;: 4999</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="w-3 text-green-400 font-bold select-none">+</span>
          <span className="text-green-400/80">&quot;cost_usd&quot;: 4999</span>
        </div>
        <div className="mt-3 pt-3 border-t border-white/5">
          <span className="label-mono">BLAST RADIUS</span>
          <div className="mt-2 flex flex-wrap gap-2">
            {['revenue-analytics', 'checkout-flow', 'invoice-gen'].map((sys) => (
              <span key={sys} className="px-2 py-0.5 rounded text-orange-400/80 border border-orange-400/20 text-xs font-mono-data">
                {sys}
              </span>
            ))}
          </div>
        </div>
        <div className="pt-3 border-t border-white/5">
          <span className="label-mono">AUTO-PATCH</span>
          <div className="mt-1.5 text-signal font-mono-data text-xs">
            ✓ Patch applied in 340ms · 0 downstream failures
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export function Hero() {
  return (
    <section className="relative min-h-screen pt-28 pb-24 flex flex-col items-center justify-center overflow-hidden">
      <DataStream />

      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <div className="flex flex-col lg:flex-row gap-16 items-center">

          {/* Left — Copy */}
          <div className="flex-1 min-w-0">
            {/* Status badge */}
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 liquid-glass px-3 py-1.5 rounded mb-8"
            >
              <span className="status-dot" />
              <span className="label-mono">Data Immune System · Now in Private Beta</span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.8 }}
              className="font-instrument-serif text-5xl md:text-6xl xl:text-7xl leading-tight mb-6 text-balance"
            >
              Your data pipelines{' '}
              <span className="italic text-gradient">never sleep.</span>
              <br />
              <span className="italic">Neither does</span>{' '}
              <span className="text-gradient">SUNDER.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35, duration: 0.8 }}
              className="text-foreground/55 text-lg leading-relaxed max-w-lg mb-10"
            >
              Autonomous middleware that detects silent schema drift, maps the blast radius across every downstream system, and self-applies a patch — before a single record corrupts.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap gap-3"
            >
              <button className="liquid-glass-accent px-6 py-3 rounded font-semibold text-sm tracking-wide hover:glow-cyan transition-all">
                Request Early Access
              </button>
              <button className="liquid-glass px-6 py-3 rounded font-semibold text-sm tracking-wide text-foreground/70 hover:text-foreground transition-colors">
                Watch 90-Second Demo
              </button>
            </motion.div>

            {/* Trust stats */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="flex flex-wrap gap-8 mt-12"
            >
              {[
                { value: '$2.4M', label: 'Pipeline damage prevented (beta)' },
                { value: '340ms', label: 'Median patch latency' },
                { value: '100%', label: 'Downstream uptime maintained' },
              ].map(({ value, label }) => (
                <div key={label}>
                  <div className="font-instrument-serif text-3xl italic text-signal">{value}</div>
                  <div className="label-mono mt-1">{label}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right — Live schema-diff card */}
          <div className="flex-shrink-0 w-full lg:w-auto">
            <SchemaDiffCard />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        aria-hidden
      >
        <div className="w-5 h-8 rounded-full border border-white/15 flex items-center justify-center">
          <div className="w-0.5 h-2 bg-white/40 rounded-full" />
        </div>
      </motion.div>
    </section>
  )
}
