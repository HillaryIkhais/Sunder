'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'

export function CTA() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setEmail('')
    setTimeout(() => setSubmitted(false), 4000)
  }

  return (
    <section id="pricing" className="py-32 px-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(0,220,255,0.12), transparent)' }} />

      {/* Radial glow behind CTA */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(0,220,255,0.04) 0%, transparent 70%)' }}
      />

      <div className="max-w-3xl mx-auto text-center relative z-10">
        {/* Status badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 liquid-glass px-3 py-1.5 rounded mb-10"
        >
          <span className="status-dot" />
          <span className="label-mono">Private Beta · 12 Spots Remaining</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="font-instrument-serif text-4xl md:text-5xl xl:text-6xl mb-6 text-balance"
        >
          Your next{' '}
          <span className="italic text-gradient">silent outage</span>
          <br />
          <span className="italic">is already in motion.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-foreground/55 text-lg leading-relaxed mb-12 max-w-xl mx-auto"
        >
          Join the data engineering teams and CDOs already running SUNDER in production. Be the person who stops the 3 AM fire before it starts.
        </motion.p>

        {/* Email form */}
        <motion.form
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          onSubmit={handleSubmit}
          className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto mb-10"
        >
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@yourcompany.com"
            required
            className="flex-1 px-5 py-3 bg-white/5 border border-white/10 rounded text-sm text-foreground placeholder-foreground/30 focus:outline-none focus:border-cyan-500/40 transition-colors font-mono-data"
          />
          <motion.button
            type="submit"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="liquid-glass-accent px-6 py-3 rounded font-semibold text-sm tracking-wide text-foreground whitespace-nowrap hover:glow-cyan transition-all"
          >
            {submitted ? 'Request Received' : 'Request Access'}
          </motion.button>
        </motion.form>

        {/* Trust notes */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.45 }}
          className="flex flex-wrap justify-center gap-6"
        >
          {[
            'No credit card required',
            'SOC 2 Type II in progress',
            'Dedicated onboarding engineer',
          ].map((note) => (
            <span key={note} className="label-mono flex items-center gap-1.5">
              <span className="text-signal">✓</span>
              {note}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
