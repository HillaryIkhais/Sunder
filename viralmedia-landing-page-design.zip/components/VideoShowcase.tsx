'use client'

import { motion, useInView } from 'framer-motion'
import { useRef, useState } from 'react'

/* Animated pipeline flow visualization */
function PipelineViz() {
  const nodes = [
    { id: 'shopify', label: 'Shopify', type: 'source', x: 0, status: 'ok' },
    { id: 'stripe', label: 'Stripe', type: 'source', x: 0, status: 'mutated' },
    { id: 'sunder', label: 'SUNDER', type: 'engine', x: 1, status: 'intercepted' },
    { id: 'snowflake', label: 'Snowflake', type: 'dest', x: 2, status: 'ok' },
    { id: 'dbt', label: 'dbt Cloud', type: 'dest', x: 2, status: 'ok' },
    { id: 'analytics', label: 'Revenue Analytics', type: 'dest', x: 2, status: 'ok' },
  ]

  const statusColors: Record<string, string> = {
    ok: 'oklch(0.82 0.22 140)',
    mutated: 'oklch(0.65 0.22 25)',
    intercepted: 'oklch(0.85 0.18 195)',
  }

  return (
    <div className="w-full rounded-xl liquid-glass overflow-hidden" style={{ border: '1px solid rgba(0,220,255,0.1)' }}>
      {/* Chrome bar */}
      <div className="flex items-center justify-between px-5 py-3 border-b" style={{ borderColor: 'rgba(0,220,255,0.08)' }}>
        <span className="label-mono">PIPELINE_MONITOR · LIVE</span>
        <div className="flex items-center gap-2">
          <span className="status-dot" />
          <span className="label-mono">SUNDER INTERCEPTING</span>
        </div>
      </div>

      {/* Pipeline layout */}
      <div className="p-6 md:p-10">
        <div className="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
          {/* Sources */}
          <div className="flex flex-col gap-4 flex-shrink-0">
            <span className="label-mono text-center block mb-2">Sources</span>
            {[nodes[0], nodes[1]].map((n, i) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.2 }}
                className="liquid-glass rounded-lg px-4 py-3 flex items-center gap-3 min-w-[130px]"
                style={{ border: `1px solid ${statusColors[n.status]}33` }}
              >
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: statusColors[n.status], boxShadow: `0 0 6px ${statusColors[n.status]}` }} />
                <span className="text-sm font-mono-data text-foreground/80">{n.label}</span>
                {n.status === 'mutated' && (
                  <span className="text-xs font-mono-data px-1.5 py-0.5 rounded" style={{ background: 'rgba(255,80,80,0.12)', color: 'oklch(0.65 0.22 25)', border: '1px solid rgba(255,80,80,0.2)' }}>
                    DRIFT
                  </span>
                )}
              </motion.div>
            ))}
          </div>

          {/* Animated arrows left */}
          <div className="flex flex-col gap-4 items-center flex-shrink-0">
            {[0, 1].map((i) => (
              <motion.div
                key={i}
                className="h-px w-12 md:w-20"
                style={{ background: i === 1 ? 'rgba(255,80,80,0.5)' : 'rgba(0,220,255,0.3)' }}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.6 + i * 0.15, duration: 0.5 }}
              />
            ))}
          </div>

          {/* SUNDER engine node */}
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            className="flex-shrink-0 relative"
          >
            <div className="liquid-glass-accent rounded-xl px-6 py-5 text-center relative z-10 min-w-[150px]">
              <div className="w-3 h-3 rounded-full mx-auto mb-2" style={{ background: 'oklch(0.85 0.18 195)', boxShadow: '0 0 14px oklch(0.85 0.18 195)' }} />
              <span className="font-instrument-serif text-xl italic text-signal block">SUNDER</span>
              <span className="label-mono mt-1 block text-signal/60">PATCHING</span>
            </div>
            {/* Radial glow */}
            <div className="absolute inset-0 rounded-xl blur-2xl -z-10" style={{ background: 'rgba(0,220,255,0.07)' }} />
          </motion.div>

          {/* Animated arrows right */}
          <div className="flex flex-col gap-4 items-center flex-shrink-0">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="h-px w-12 md:w-20"
                style={{ background: 'rgba(130,255,160,0.35)' }}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 1.0 + i * 0.1, duration: 0.5 }}
              />
            ))}
          </div>

          {/* Destinations */}
          <div className="flex flex-col gap-3 flex-shrink-0">
            <span className="label-mono text-center block mb-2">Destinations</span>
            {[nodes[3], nodes[4], nodes[5]].map((n, i) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.1 + i * 0.15 }}
                className="liquid-glass rounded-lg px-4 py-2.5 flex items-center gap-3"
                style={{ border: `1px solid ${statusColors[n.status]}33` }}
              >
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: statusColors[n.status], boxShadow: `0 0 6px ${statusColors[n.status]}` }} />
                <span className="text-sm font-mono-data text-foreground/70">{n.label}</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom summary row */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4 }}
          className="mt-8 pt-5 border-t flex flex-wrap gap-6"
          style={{ borderColor: 'rgba(0,220,255,0.07)' }}
        >
          {[
            { label: 'MUTATION_TYPE', value: 'FIELD_RENAME' },
            { label: 'FIELDS_AFFECTED', value: '1 · price → cost_usd' },
            { label: 'PATCH_STATUS', value: 'APPLIED · 340ms' },
            { label: 'DOWNSTREAM_FAILURES', value: '0' },
          ].map(({ label, value }) => (
            <div key={label}>
              <span className="label-mono block">{label}</span>
              <span className="font-mono-data text-sm text-signal mt-0.5 block">{value}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

export function VideoShowcase() {
  return (
    <section className="py-32 px-6 relative">
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(0,220,255,0.12), transparent)' }} />

      <div className="max-w-6xl mx-auto">
        <div className="mb-12">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="label-mono block mb-4"
          >
            Real-Time Visualization
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-instrument-serif text-4xl md:text-5xl xl:text-6xl text-balance"
          >
            Watch SUNDER{' '}
            <span className="italic text-gradient">intercept the drift</span>
            <br />
            in real time.
          </motion.h2>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <PipelineViz />
        </motion.div>
      </div>
    </section>
  )
}
