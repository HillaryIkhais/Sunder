'use client'

import { motion, useScroll, useTransform } from 'framer-motion'
import Link from 'next/link'

export function Navbar() {
  const { scrollY } = useScroll()
  const borderOpacity = useTransform(scrollY, [0, 80], [0, 1])

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: 'easeOut' }}
      className="fixed top-0 w-full z-50 bg-black/60 backdrop-blur-xl"
      style={{ borderBottom: '1px solid rgba(0,220,255,0.08)' }}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-3 group">
          <div className="relative w-7 h-7 flex items-center justify-center">
            {/* Animated shield / S mark */}
            <svg viewBox="0 0 28 28" fill="none" className="w-7 h-7">
              <path
                d="M14 2L4 6v8c0 5.5 4.3 10.7 10 12 5.7-1.3 10-6.5 10-12V6L14 2z"
                stroke="oklch(0.85 0.18 195)"
                strokeWidth="1.5"
                fill="rgba(0,220,255,0.06)"
              />
              <path d="M10 14l3 3 5-5" stroke="oklch(0.82 0.22 140)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            {/* Pulse ring */}
            <span className="absolute inset-0 rounded-full border border-cyan-500/20 animate-ping" style={{ animationDuration: '3s' }} />
          </div>
          <span className="font-instrument-serif text-xl italic tracking-wide text-white">SUNDER</span>
        </Link>

        {/* Nav links with monospace label treatment */}
        <div className="hidden md:flex items-center gap-8">
          {[
            { label: 'How It Works', href: '#how' },
            { label: 'Who It&apos;s For', href: '#who' },
            { label: 'Pricing', href: '#pricing' },
            { label: 'Docs', href: '#docs' },
          ].map(({ label, href }) => (
            <Link
              key={href}
              href={href}
              className="text-sm text-foreground/50 hover:text-foreground transition-colors tracking-wide"
              dangerouslySetInnerHTML={{ __html: label }}
            />
          ))}
        </div>

        {/* Status + CTA */}
        <div className="flex items-center gap-4">
          {/* Live status indicator */}
          <div className="hidden md:flex items-center gap-2 label-mono">
            <span className="status-dot" />
            <span>SYSTEM ACTIVE</span>
          </div>
          <button className="liquid-glass-accent px-5 py-2 rounded text-sm font-semibold text-foreground hover:glow-cyan transition-all tracking-wide">
            Request Access
          </button>
        </div>
      </div>
    </motion.nav>
  )
}
