'use client'

import { motion } from 'framer-motion'

const audiences = [
  {
    id: 'DATA_ENG',
    role: 'Data Engineering Teams',
    pain: '3 AM on-call pages because a vendor changed an API field name.',
    outcome: 'Sleep through the night. SUNDER detects, patches, and logs — before your alerting even fires.',
    metrics: ['84% reduction in pipeline incidents', 'Avg. 340ms patch latency', 'Full audit trail'],
    accent: 'oklch(0.85 0.18 195)',
  },
  {
    id: 'FINTECH',
    role: 'FinTech & E-commerce',
    pain: 'One hour of corrupted revenue data between Shopify → Stripe → analytics costs thousands.',
    outcome: 'Continuous semantic validation on every transaction event. No silent corruption. No revenue black holes.',
    metrics: ['$2.4M damage prevented (beta)', 'Shopify + Stripe connectors built-in', 'Real-time blast-radius alerts'],
    accent: 'oklch(0.82 0.22 140)',
  },
  {
    id: 'CDO',
    role: 'Chief Data Officers',
    pain: 'Executives making financial forecasts on silently corrupted data they believe is clean.',
    outcome: 'A cryptographic audit trail proves every data field that entered your warehouse was validated, translated, and certified.',
    metrics: ['Board-ready data provenance', 'SOC 2 compatible audit logs', 'CISO-friendly zero-trust model'],
    accent: 'oklch(0.75 0.15 280)',
  },
]

const integrationLogos = [
  'Shopify', 'Stripe', 'Snowflake', 'dbt', 'Fivetran', 'Kafka', 'Postgres', 'BigQuery',
]

export function SelectedWork() {
  return (
    <section id="who" className="py-32 px-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(0,220,255,0.12), transparent)' }} />

      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="label-mono block mb-4"
          >
            Who It&apos;s Built For
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-instrument-serif text-4xl md:text-5xl xl:text-6xl text-balance"
          >
            <span className="italic">Enterprise teams</span> that can&apos;t afford{' '}
            <span className="text-gradient italic">data surprises.</span>
          </motion.h2>
        </div>

        {/* Audience cards */}
        <div className="space-y-5 mb-24">
          {audiences.map((a, idx) => (
            <motion.div
              key={a.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.12, duration: 0.7 }}
              className="liquid-glass rounded-xl p-6 md:p-8 group"
              style={{ border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <div className="grid md:grid-cols-12 gap-6 items-start">
                {/* ID + Role */}
                <div className="md:col-span-3">
                  <span className="label-mono" style={{ color: `${a.accent}99` }}>{a.id}</span>
                  <h3 className="mt-2 font-semibold text-foreground text-lg leading-snug">{a.role}</h3>
                </div>

                {/* Pain */}
                <div className="md:col-span-4">
                  <span className="label-mono block mb-2">The Pain</span>
                  <p className="text-foreground/50 text-sm leading-relaxed">{a.pain}</p>
                </div>

                {/* Outcome */}
                <div className="md:col-span-5">
                  <span className="label-mono block mb-2">With SUNDER</span>
                  <p className="text-foreground/70 text-sm leading-relaxed mb-4">{a.outcome}</p>
                  <ul className="space-y-1.5">
                    {a.metrics.map((m) => (
                      <li key={m} className="flex items-center gap-2 text-xs font-mono-data" style={{ color: a.accent }}>
                        <span className="opacity-60">→</span>
                        <span>{m}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              {/* Hover accent */}
              <div className="mt-6 h-px w-0 group-hover:w-full transition-all duration-700"
                style={{ background: `linear-gradient(to right, ${a.accent}, transparent)` }}
              />
            </motion.div>
          ))}
        </div>

        {/* Integrations strip */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <span className="label-mono block mb-6 text-center">Connects with your existing stack</span>
          <div className="flex flex-wrap justify-center gap-3">
            {integrationLogos.map((name) => (
              <div
                key={name}
                className="liquid-glass px-4 py-2 rounded text-sm font-mono-data text-foreground/50 hover:text-signal hover:border-cyan-500/20 transition-all"
                style={{ border: '1px solid rgba(255,255,255,0.07)' }}
              >
                {name}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
