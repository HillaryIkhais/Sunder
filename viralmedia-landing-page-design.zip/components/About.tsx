'use client'

import { motion } from 'framer-motion'

const problem = {
  title: 'The Silent $84B Problem',
  body: 'Every time a vendor updates their API, thousands of enterprise pipelines silently break. Standard monitoring tools see a valid number — they have no idea the field name just changed from `price` to `cost_usd`. By the time a human notices, the damage is already in production.',
}

const capabilities = [
  {
    id: '01',
    title: 'Semantic Schema Understanding',
    body: 'Vector embeddings give SUNDER a semantic understanding of every data field — not just its name or type, but its meaning. When `price` becomes `cost_usd`, SUNDER knows they are the same concept.',
    signal: 'EMBEDDING_ENGINE',
  },
  {
    id: '02',
    title: 'Blast Radius Mapping',
    body: 'Before a mutation propagates, SUNDER traces the full dependency graph. Every downstream system that depends on the changed field is flagged, quantified by risk, and queued for patching.',
    signal: 'IMPACT_GRAPH',
  },
  {
    id: '03',
    title: 'Autonomous Code Patching',
    body: 'SUNDER generates and applies a translation patch in the middleware layer before corrupted data ever reaches a downstream consumer. Zero manual intervention. Zero 3 AM pages.',
    signal: 'AUTO_PATCH',
  },
]

export function About() {
  return (
    <section id="how" className="py-32 px-6 relative">
      {/* Subtle horizontal scanline divider */}
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(0,220,255,0.12), transparent)' }} />

      <div className="max-w-6xl mx-auto">
        {/* Problem statement */}
        <div className="grid lg:grid-cols-2 gap-12 mb-24 items-start">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <span className="label-mono mb-4 block">The Problem</span>
            <h2 className="font-instrument-serif text-4xl md:text-5xl xl:text-6xl leading-tight text-balance">
              <span className="italic">Silent</span> drift.{' '}
              <span className="text-gradient italic">Loud</span> consequences.
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="flex flex-col justify-center gap-6"
          >
            <p className="text-foreground/60 leading-relaxed text-lg">{problem.body}</p>
            {/* Mini cost callout */}
            <div className="liquid-glass rounded-lg p-5 flex items-start gap-4">
              <div className="status-dot mt-1.5 flex-shrink-0" style={{ background: 'oklch(0.65 0.22 25)', boxShadow: '0 0 8px oklch(0.65 0.22 25)' }} />
              <div>
                <p className="label-mono mb-1">Industry data · Gartner 2024</p>
                <p className="text-foreground/70 text-sm leading-relaxed">
                  Poor data quality costs organizations an average of <span className="text-signal font-semibold">$12.9M per year.</span> Silent schema mutations are the leading unmonitored cause.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* How SUNDER works */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <span className="label-mono">How It Works</span>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-5">
          {capabilities.map((cap, idx) => (
            <motion.div
              key={cap.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.12, duration: 0.7 }}
              className="liquid-glass rounded-xl p-6 group hover:border-cyan-500/20 transition-all"
              style={{ border: '1px solid rgba(255,255,255,0.07)' }}
            >
              {/* Signal label */}
              <div className="flex items-center justify-between mb-5">
                <span className="label-mono text-signal/70">{cap.signal}</span>
                <span className="font-mono-data text-2xl font-bold text-white/10">{cap.id}</span>
              </div>
              <h3 className="font-semibold text-foreground text-base mb-3 leading-snug">{cap.title}</h3>
              <p className="text-foreground/50 text-sm leading-relaxed">{cap.body}</p>
              {/* Hover accent line */}
              <div className="mt-6 h-px w-0 group-hover:w-full transition-all duration-500"
                style={{ background: 'linear-gradient(to right, oklch(0.85 0.18 195), oklch(0.82 0.22 140))' }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
