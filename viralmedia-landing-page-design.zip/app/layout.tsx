import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Barlow, Instrument_Serif } from 'next/font/google'
import './globals.css'

const barlow = Barlow({
  variable: '--font-barlow',
  weight: ['400', '500', '600', '700'],
  subsets: ['latin'],
})

const instrumentSerif = Instrument_Serif({
  variable: '--font-instrument-serif',
  weight: ['400'],
  subsets: ['latin'],
})

export const metadata: Metadata = {
  title: 'SUNDER — Autonomous Data Immune System',
  description: 'SUNDER detects silent schema drift, maps blast radius, and self-applies code patches before a single downstream record corrupts. Built for data engineering teams, FinTech, and Chief Data Officers.',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: [{ media: '(prefers-color-scheme: dark)', color: '#0a0a0a' }],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${barlow.variable} ${instrumentSerif.variable} dark`} style={{ background: 'oklch(0.06 0 0)' }}>
      <body className="font-barlow antialiased overflow-x-hidden" style={{ background: 'oklch(0.06 0 0)', color: 'oklch(0.93 0 0)' }}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
